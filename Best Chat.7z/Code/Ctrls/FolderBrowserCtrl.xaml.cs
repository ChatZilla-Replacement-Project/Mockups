﻿// Ignore Spelling: Ctrl Ctrls

namespace BestChat.GUI.Ctrls
{
	/// <summary>
	/// Interaction logic for FolderBrowserCtrl.xaml
	/// </summary>
	public partial class FolderBrowserCtrl : System.Windows.Controls.UserControl
	{
		public FolderBrowserCtrl()
		{
			InitializeComponent();
		}
	}
}