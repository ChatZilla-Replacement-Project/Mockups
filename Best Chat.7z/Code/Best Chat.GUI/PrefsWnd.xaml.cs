﻿// Ignore Spelling: Prefs

namespace BestChat.GUI
{
	/// <summary>
	/// Interaction logic for PrefsWnd.xaml
	/// </summary>
	public partial class PrefsWnd : System.Windows.Window
	{
		public PrefsWnd()
		{
			InitializeComponent();
		}
	}
}