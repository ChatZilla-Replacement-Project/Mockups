﻿namespace BestChat.GUI
{
	/// <summary>
	/// Interaction logic for MainWnd.xaml
	/// </summary>
	public partial class MainWnd : System.Windows.Window
	{
		public MainWnd()
		{
			InitializeComponent();
		}

		private void OnNetworkListClicked(object sender, System.Windows.RoutedEventArgs e)
		{

		}

		private void OnFileExitClicked(object sender, System.Windows.RoutedEventArgs e) => Close();

		private void OnPrefsClicked(object sender, System.Windows.RoutedEventArgs e)
		{
			PrefsWnd dlg = new PrefsWnd();

			dlg.Show();
		}
	}
}