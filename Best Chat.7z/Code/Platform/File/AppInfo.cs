﻿// Ignore Spelling: Loc

using System.Linq;

namespace BestChat.Platform.Data
{
	/// <summary>
	/// Allows DLL assemblies to get information on the app like the developer name and product name.  From those values, they can compute where to store files.
	/// </summary>
	public class AppInfo
	{
		/// <summary>
		/// Initializes the static fields
		/// </summary>
		/// <exception cref="System.InvalidOperationException">No entry assembly found.  Should never happen.</exception>
		static AppInfo()
		{
			System.Reflection.Assembly? assemblyApp = System.Reflection.Assembly.GetEntryAssembly() ?? throw new System
				.InvalidOperationException("Can't find an entry assembly");

			System.Collections.Generic.IEnumerable<object> collCustomAttrForAssembly = assemblyApp
				.GetCustomAttributes(true);

			strDeveloperName = (
				from attrCur in collCustomAttrForAssembly
				where attrCur is System.Reflection.AssemblyCompanyAttribute
				select attrCur as System.Reflection.AssemblyCompanyAttribute).First().Company;

			strProductName = (
				from attrCur in collCustomAttrForAssembly
				where attrCur is System.Reflection.AssemblyProductAttribute
				select attrCur as System.Reflection.AssemblyProductAttribute).First().Product;

			dirSettingsLoc = new(System.IO.Path.Combine(System
				.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData, System.Environment
				.SpecialFolderOption.Create), strDeveloperName, strProductName));
		}

		/// <summary>
		/// The name of the developer
		/// </summary>
		public static readonly string strDeveloperName;

		/// <summary>
		/// The name of the product
		/// </summary>
		public static readonly string strProductName;

		/// <summary>
		/// Where to store all settings files.
		/// </summary>
		public static readonly System.IO.DirectoryInfo dirSettingsLoc;
	}
}