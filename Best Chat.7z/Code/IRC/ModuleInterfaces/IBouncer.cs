﻿// Ignore Spelling: IRC

namespace BestChat.IRC.ModuleInterfaces
{
	public interface IBouncer
	{
		string Name
		{
			get;
		}

		System.Uri Homepage
		{
			get;
		}

		System.Collections.Generic.IReadOnlyList<string> bannedNetworks
		{
			get;
		}
	}
}