﻿// Ignore Spelling: Defs evt

using System.Linq;

namespace BestChat.Data.Defs
{
	public class Network : Platform.Data.Obj<Network>
	{
		#region Constructors & Deconstructors
			public Network()
			{
			}

			public Network(string strName, System.Uri uriHomepage)
			{
				this.strName = strName;
				this.uriHomepage = uriHomepage;
			}
		#endregion

		#region Delegates
		#endregion

		#region Events
			public event DFieldChanged<string>? evtNameChanged;
			public event DFieldChanged<System.Uri>? evtHomepageChanged;
			public event DBoolFieldChanged? evtAutoConnectChanged;
			public event DBoolFieldChanged? evtHidden;
			public event DCollectionFieldChanged<System.Collections.Generic.IReadOnlyDictionary<string, ServerInfo>>?
				evtServersChanged;
			public event DFieldChanged<IRC.ModuleInterfaces.INetwork?>? evtDefaultsChanged;

			public override event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
		#endregion

		#region Constants
			public struct PropNames
			{
				public const string strName = nameof(Name);
				public const string strHomepage = nameof(Homepage);
				public const string strAutoConnect = nameof(AutoConnect);
				public const string strHidden = nameof(Hidden);
				public const string strServers = nameof(Servers);
				public const string strDefaults = nameof(defaults);
			}
		#endregion

		#region Helper Types
			public class ServerInfo : Platform.Data.Obj<ServerInfo>
			{
				#region Constructors & Deconstructors
					public ServerInfo()
					{
						strDomain = "";
					}

					public ServerInfo(string strDomain)
					{
						this.strDomain = strDomain;
						bEnabled = true;
					}
				#endregion

				#region Delegates
				#endregion

				#region Events
					public event DFieldChanged<string>? evtDomainChanged;
					public event DBoolFieldChanged? evtEnabledChanged;

					public override event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
				#endregion

				#region Constants
					public struct PropNames
					{
						public const string strDomain = nameof(Domain);
						public const string strEnabled = nameof(IsEnabled);
					}
				#endregion

				#region Helper Types
				#endregion

				#region Members
					private string strDomain;
					private bool bEnabled;
				#endregion

				#region Properties
					public string Domain
					{
						get => strDomain;

						protected set
						{
							if(strDomain!= value)
							{
								string strOldDomain = strDomain;

								strDomain = value;

								MakeDirty();

								FireDomainChanged(strOldDomain);
							}
						}
					}

					public bool IsEnabled
					{
						get => bEnabled;

						set
						{
							if(bEnabled!= value)
							{
								bEnabled = value;

								MakeDirty();

								FireEnabledChanged();
							}
						}
					}
				#endregion

				#region Methods
					protected void FirePropChanged(string strPropName)
					{
						PropertyChanged?.Invoke(this, new(strPropName));
					}

					protected void FireDomainChanged(string strOldDomain)
					{
						FirePropChanged(PropNames.strDomain);

						evtDomainChanged?.Invoke(this, strOldDomain, strDomain);
					}

					protected void FireEnabledChanged()
					{
						FirePropChanged(PropNames.strEnabled);

						evtEnabledChanged?.Invoke(this, bEnabled);
					}
				#endregion

				#region Operators
					public static implicit operator ServerInfo(string strServerName) => new ServerInfo(strServerName);
				#endregion

				#region Event Handlers
				#endregion
			}
		#endregion

		#region Members
			private string? strName;
			private System.Uri? uriHomepage;
			private bool bAutoConnect;
			private bool bHidden;

			private IRC.ModuleInterfaces.INetwork? defaults;

			private readonly System.Collections.Generic.SortedDictionary<string, ServerInfo> mapServers = new();
		#endregion

		#region Properties
			public string Name
			{
				get
				{
					if(strName == null)
						if(defaults == null)
							throw new System.InvalidProgramException("Both the internal name and default object are null");
						else
							return defaults.Name;
					else
						return strName;
				}

				protected set
				{
					if(strName != value)
					{
						string strOldValue = strName ?? (defaults == null ? "" : defaults.Name);

						strName = value;

						MakeDirty();

						FireNameChanged(strOldValue);
					}
				}
			}

			public System.Uri Homepage
			{
				get
				{
					if(uriHomepage == null)
						if(defaults == null)
							throw new System.InvalidProgramException("Both the internal homepage and default object are null");
						else
							return defaults.Homepage;
					else
						return uriHomepage;
				}

				protected set
				{
					if(uriHomepage != value)
					{
						System.Uri uriOldHomepage = uriHomepage ?? (defaults == null ? new System.Uri("google.com") :
							defaults.Homepage);

						uriHomepage = value;

						MakeDirty();

						FireHomepageChanged(uriOldHomepage);
					}
				}
			}

			public bool AutoConnect
			{
				get => bAutoConnect;

				set
				{
					if(bAutoConnect != value)
					{
						bAutoConnect = value;

						MakeDirty();

						FireAutoConnectChanged();
					}
				}
			}

			public bool Hidden
			{
				get => bHidden;

				set
				{
					if(bHidden != value)
					{
						bHidden = value;

						MakeDirty();

						FireHiddenChanged();
					}
				}
			}

			public System.Collections.Generic.IReadOnlyDictionary<string, ServerInfo> Servers
			{
				get
				{
					if(defaults  == null)
						return mapServers;

					if(mapServers.Count == 0)
						return (System.Collections.Generic.IReadOnlyDictionary<string, ServerInfo>)defaults.ServerDomains
							.Select((string strCurDomain) => new System.Collections.Generic.KeyValuePair<string,
							ServerInfo>(strCurDomain, new ServerInfo(strCurDomain)));

					return mapServers;
				}
			}

			public IRC.ModuleInterfaces.INetwork? Defaults => defaults;

		#endregion

		#region Methods
			protected void FirePropChanged(string strPropName)
			{
				PropertyChanged?.Invoke(this, new(strPropName));
			}

			protected void FireNameChanged(string strOldVal)
			{
				FirePropChanged(PropNames.strName);

				evtNameChanged?.Invoke(this, strOldVal, strName ?? (defaults == null ? "" : defaults.Name));
			}

			protected void FireHomepageChanged(System.Uri uriOldHomepage)
			{
				FirePropChanged(PropNames.strHomepage);

				evtHomepageChanged?.Invoke(this, uriOldHomepage, uriHomepage ?? (defaults == null ? new System
					.Uri("google.com") : defaults.Homepage));
			}

			protected void FireAutoConnectChanged()
			{
				FirePropChanged(PropNames.strAutoConnect);

				evtAutoConnectChanged?.Invoke(this, bAutoConnect);
			}

			protected void FireHiddenChanged()
			{
				FirePropChanged(PropNames.strHidden);

				evtHidden?.Invoke(this, bHidden);
			}

			protected void FireServersChanged(CollectionChangeType howTheCollectionChanged)
			{
				FirePropChanged(PropNames.strServers);

				evtServersChanged?.Invoke(this, mapServers, howTheCollectionChanged);
			}

			protected void FireDefaultsChanged(IRC.ModuleInterfaces.INetwork? defaultsOld)
			{
				FirePropChanged(PropNames.strDefaults);

				evtDefaultsChanged?.Invoke(this, defaultsOld, defaults);
			}

			protected void AddServerDomain(ServerInfo server)
			{
				if(mapServers.ContainsKey(server.Domain))
					throw new System.NotSupportedException("This server is already present");

				mapServers[server.Domain] = server;

				FireServersChanged(CollectionChangeType.add);
			}

			protected void DelServerDomain(ServerInfo server)
			{
				if(!mapServers.ContainsKey(server.Domain))
					return;

				mapServers.Remove(server.Domain);

				FireServersChanged(CollectionChangeType.removed);
			}
		#endregion

		#region Event Handlers
		#endregion
	}
}