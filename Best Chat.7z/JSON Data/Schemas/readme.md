A "lite" schema omits some fields.  Those are intended for use when the instance file will only exist online.  Instance files on the local machine should use a "full" schema.
